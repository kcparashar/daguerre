# convert bancroft.gif -resize 10% bancroft.gif;
# convert glade.gif -resize 10% glade.gif;

convert hills_mini.jpg -resize 10% hills_mini.jpg;
convert hills.jpg -resize 10% hills.jpg;
convert mason_jar.jpg -resize 10% mason_jar.jpg;
convert mlk_camera.jpg -resize 10% mlk_camera.jpg;
convert mlk_mini.jpg -resize 10% mlk_mini.jpg;
convert mlk.jpg -resize 10% mlk.jpg;
convert trash_mini.jpg -resize 10% trash_mini.jpg;
convert trash.jpg -resize 10% trash.jpg;


